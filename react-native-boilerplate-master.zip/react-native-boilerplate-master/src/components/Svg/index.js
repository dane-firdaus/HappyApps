import Svg from './Svg'

export default Svg
