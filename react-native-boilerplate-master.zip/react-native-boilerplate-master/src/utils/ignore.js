import { LogBox } from 'react-native'

// eslint-disable-next-line no-unused-expressions
LogBox?.ignoreLogs(['Remote debugger'])
