import Routes from './Routes'

export default Routes
