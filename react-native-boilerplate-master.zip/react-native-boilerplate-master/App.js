import App from './src/index'
export default App
