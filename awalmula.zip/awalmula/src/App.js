import logo from "./logo.svg";
import Home from "./Component";
import "./App.css";
import { Carousel } from "bootstrap";

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <Home />

        
       
      </header>
    </div>
  );
}

export default App;
