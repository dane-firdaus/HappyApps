import { Component } from "react";
import "./Badans.css";
import { Card, Container, Carousel } from "react-bootstrap";

export class Juzzs extends Component {
  render() {
    return (
      <div >
        <center>
          
            <Carousel className="cartu">
              <Carousel.Item className="Carousel" interval={1000}>
                <img className="d-block w-100 Carousel" src="https://micro-blog.awalmula.co/wp-content/uploads/2021/11/Banner-homepage_1_revisi.png" alt="First slide" />
                <Carousel.Caption></Carousel.Caption>
              </Carousel.Item>
              <Carousel.Item className="Carousel" interval={1000}>
                <img className="d-block w-100 Carousel" src="https://micro-blog.awalmula.co/wp-content/uploads/2021/12/youga.png" alt="Second slide" />
                <Carousel.Caption></Carousel.Caption>
              </Carousel.Item>
              <Carousel.Item className="Carousel" interval={1000}>
                <img className="d-block w-100 Carousel" src="https://micro-blog.awalmula.co/wp-content/uploads/2021/12/cece.png" alt="Third slide" />
                <Carousel.Caption></Carousel.Caption>
              </Carousel.Item>
            </Carousel>
          
        </center>
      </div>
    );
  }
}
