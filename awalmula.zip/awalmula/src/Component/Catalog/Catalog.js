import { Component, useState } from "react";
import { Container, Row, Col, Button, Card, ListGroup } from "react-bootstrap";
import axios from "axios";
import "./Catalog.css";

class Catalogs extends Component {
  state = {
    Category: [],
    url1: "https://staging-cuan.awalmula.co/rest/default/V1/categories",
    url2: "https://staging-cuan.awalmula.co/rest/default/V1/categories/${id}",
  };
  componentDidMount() {
    axios.get(this.state.url1).then((res) => {
      console.log(res.data.children_data);
      const Category = res.data.children_data;
      this.setState({ Category });
      //   const persons = res.data;
      // this.setState({ persons });
    });
  }
  render() {
    return (
      <div>
        <Container>
          <Row>
            {this.state.Category?.map((Dor) => (
              <Col xs className="cl">
                <button className="bts">{Dor.name}</button>
              </Col>
            ))}
          </Row>
        </Container>
      </div>
    );
  }
}
export default Catalogs;
