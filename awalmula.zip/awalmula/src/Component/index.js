import { Component } from "react";
import { Navbar, Container } from "react-bootstrap";
import { Juzzs } from "./Badans";
import Navs from "./Nav";
import Catalogs from "./Catalog/Catalog";
import Produks from "./Produk/Produk";
import "./index.css";

class Home extends Component {
  render() {
    return (
      <div>
        <Navs />
        <Juzzs />
        <Catalogs />
        <Produks />
      </div>
    );
  }
}

export default Home;
