import { Component } from "react";
import axios from "axios";
import { Card, Button, Row, Col } from "react-bootstrap";
import reactDom from "react-dom";
// import { Router, Route, IndexRoute, hashHistory } from "react-router";
import App from "../../App";
import Home from "..";
import toko from "../Toko/Toko";

class Produks extends Component {
  state = {
    title: [],
    gambar: [],
  };
  componentDidMount() {
    axios.get("https://staging-cuan.awalmula.co/rest/default/V1/products?searchCriteria[pageSize]=10").then((res) => {
      console.log(res.data.items);
      const title = res.data.items;
      this.setState({ title });
      const gambar = res.data.items;
      this.setState({ gambar });
    });
  }

  render() {
    return (
      <div>
        <Row>
          {this.state.title?.map((Dors) => (
            <Col xs key={Dors.id}>
              <center>
                <Card style={{ width: "18rem", margin: 20 }}>
                  <Card.Body>
                    <Card.Title>
                      <h1>{Dors.name}</h1>
                    </Card.Title>
                    <Card.Text>Harga = {Dors.price}</Card.Text>
                    <Button variant="primary">Detail Produk</Button>
                  </Card.Body>
                </Card>
              </center>
            </Col>
          ))}
        </Row>
      </div>
    );
  }
}
// document.getElementById("root");
export default Produks;
