import { Component } from "react";
import { Navbar, Form, FormControl, Button } from "react-bootstrap";
import { Container } from "react-bootstrap";
import { BsLightbulb } from "react-icons/bs";
import LOGOS from "../Asset/awalmula.png";

class Navs extends Component {
  render() {
    return (
      <div>
        <Navbar expand="lg" variant="light" bg="light">
          <Container fluid="md">
            <Navbar.Brand className="text-white" href="#">
              <img src={LOGOS} alt="LOGOS" width={80} />
            </Navbar.Brand>
            <Form className="d-flex">
              <FormControl type="search" placeholder="search..." className="me-2" aria-label="Search" />

              <Button variant="outline-success">
                <BsLightbulb />
              </Button>
            </Form>
          </Container>
        </Navbar>
      </div>
    );
  }
}
export default Navs;
